#!/usr/bin/env bash

# shellcheck disable=SC2046
# shellcheck disable=SC2164
# shellcheck disable=SC2006
cd `dirname "$0"`
echo "compiling" "$1"
wine metaeditor.exe /compile:MQL4/Experts/"$1" /log
